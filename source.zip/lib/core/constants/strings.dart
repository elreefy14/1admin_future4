String phoneNumber= '';
String token= '';

     class AppStrings {
  static const String coach = "coach";
  static const String noRoutes = "No Routes Error";

}

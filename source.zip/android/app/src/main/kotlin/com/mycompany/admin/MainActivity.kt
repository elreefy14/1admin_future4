package com.mycompany.admin

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
